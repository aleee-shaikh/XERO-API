﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Xero.Api.Infrastructure.OAuth;
using System.Data;

namespace Xero.Api
{
    public partial class Xero : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (base.AccessToken != null)
            {
                DataTable dt = BankTransactions.GetBankTransactions(base.AccessToken);
                grdTransactions.DataSource = dt;
                grdTransactions.DataBind();
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Session["AccessToken"] != null)
            {
                DataTable dt = BankTransactions.GetBankTransactions(base.AccessToken, "api.xro/2.0/banktransactions/" + txtQuerystring.Text);
                grdTransactions.DataSource = dt;
                grdTransactions.DataBind();
            }
           
        }

    }

}