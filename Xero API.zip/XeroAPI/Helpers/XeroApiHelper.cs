﻿using System;
using System.Net;
using Xero.Api.Core;
using Xero.Api.Example.Applications.Partner;
using Xero.Api.Example.Applications.Public;
using Xero.Api.Example.MVC.Stores;
using Xero.Api.Infrastructure.Interfaces;
using Xero.Api.Infrastructure.OAuth;
using Xero.Api.Serialization;
using System.Configuration;
using Xero.Api.Infrastructure.OAuth.Signing;
using Xero.Api.Infrastructure.ThirdParty.HttpUtility;

public class ApplicationSettings
{
    public string BaseApiUrl { get; set; }
    public Consumer Consumer { get; set; }
    public object Authenticator { get; set; }
}

public static class XeroApiHelper
{
    private static ApplicationSettings _applicationSettings;

    public static string BaseUri
    {
        get
        {
            return System.Configuration.ConfigurationManager.AppSettings["BaseUri"].ToString();
        }
    }

    public static string ConsumerKey
    {
        get
        {
            return System.Configuration.ConfigurationManager.AppSettings["ConsumerKey"].ToString();
        }
    }

    public static string ConsumeSecret
    {
        get
        {
            return System.Configuration.ConfigurationManager.AppSettings["ConsumerSecret"].ToString();
        }
    }

    static XeroApiHelper()
    {

        // Refer to README.md for details
        var callbackUrl = System.Configuration.ConfigurationManager.AppSettings["BaseUri"].ToString();//"oob";
        var memoryStore = new MemoryAccessTokenStore();
        var requestTokenStore = new MemoryRequestTokenStore();
        var baseApiUrl = BaseUri;//"https://api.xero.com";

        // Consumer details for Application
        var consumerKey = ConsumerKey;//System.Configuration.ConfigurationManager.AppSettings["ConsumerKey"].ToString();// "QB7BFRUOTCGUVQUJVNPPSLDKIOEFRO";
        var consumerSecret = ConsumeSecret;//System.Configuration.ConfigurationManager.AppSettings["ConsumerSecret"].ToString();// "MBRFFY60ADQOSWT0M6UASYVIWSDQGP";

        // Signing certificate details for Partner Applications
        //var signingCertificatePath = "";// @"C:\Dev\your_public_privatekey.pfx";
        //var signingCertificatePassword = "";

        // Public Application Settings
        var publicConsumer = new Consumer(consumerKey, consumerSecret);

        //var publicAuthenticator = new PublicMvcAuthenticator(baseApiUrl, baseApiUrl, callbackUrl, memoryStore,
        //    publicConsumer, requestTokenStore);
        var publicAuthenticator = new PublicAuthenticator(baseApiUrl, baseApiUrl, callbackUrl, memoryStore);//, publicConsumer, requestTokenStore);

        var publicApplicationSettings = new ApplicationSettings
        {
            BaseApiUrl = baseApiUrl,
            Consumer = publicConsumer,
            Authenticator = publicAuthenticator
        };
        System.Web.HttpContext.Current.Session["Authenticator"] = publicAuthenticator;
        //// Partner Application Settings
        //var partnerConsumer = new Consumer(consumerKey, consumerSecret);

        //var partnerAuthenticator = new PartnerMvcAuthenticator(baseApiUrl, baseApiUrl, callbackUrl,
        //        memoryStore, signingCertificatePath, 
        //        partnerConsumer, requestTokenStore, signingCertificatePassword);

        //var partnerApplicationSettings = new ApplicationSettings
        //{
        //    BaseApiUrl = baseApiUrl,
        //    Consumer = partnerConsumer,
        //    Authenticator = partnerAuthenticator
        //};

        // Pick one
        // Choose what sort of application is appropriate. Comment out the above code (Partner Application Settings/Public Application Settings) that are not used.

        _applicationSettings = publicApplicationSettings;
        //_applicationSettings = partnerApplicationSettings;


    }

    public static ApiUser User()
    {
        return new ApiUser { Name = Environment.MachineName };
    }

    public static IConsumer Consumer()
    {
        return _applicationSettings.Consumer;
    }

    public static IMvcAuthenticator MvcAuthenticator()
    {
        return (IMvcAuthenticator)_applicationSettings.Authenticator;
    }

    public static IXeroCoreApi CoreApi()
    {
        if (_applicationSettings.Authenticator is IAuthenticator)
        {
            return new XeroCoreApi(_applicationSettings.BaseApiUrl, _applicationSettings.Authenticator as IAuthenticator,
                _applicationSettings.Consumer, User(), new DefaultMapper(), new DefaultMapper());
        }

        return null;
    }


    public static Token GetRequestToken(string requestTokenUrl = "oauth/RequestToken", string callbackUrl = "")
    {
        Token requestToken = new Token();
        var consumer = new Consumer(ConsumerKey, ConsumeSecret);
        OAuthTokens Token = new OAuthTokens(BaseUri, "oauth/RequestToken");
        var token = new Token
        {
            ConsumerKey = consumer.ConsumerKey,
            ConsumerSecret = consumer.ConsumerSecret
        };

        var req = new HttpClient(BaseUri)
        {
            UserAgent = "Xero Api wrapper - " + consumer.ConsumerKey
        };

        Uri uri = new Uri("https://api.xero.com/oauth/RequestToken");

        if (System.Web.HttpContext.Current.Session["requestToken"] == null)
        {
            var header = new HmacSha1Signer().CreateSignature(token, uri, "POST", null, callbackUrl);
            req.AddHeader("Authorization", header);
            var response = req.Post("oauth/RequestToken", string.Empty);

            if (response.StatusCode != HttpStatusCode.OK)
            {
                throw new OAuthException(response.Body);
            }

            var qs = HttpUtility.ParseQueryString(response.Body);
            var expires = qs["oauth_expires_in"];
            var session = qs["oauth_session_handle"];

            requestToken = new Token(consumer.ConsumerKey, consumer.ConsumerSecret)
            {
                TokenKey = qs["oauth_token"],
                TokenSecret = qs["oauth_token_secret"],
                OrganisationId = qs["xero_org_muid"]
            };

            if (requestToken != null)
            {
                System.Web.HttpContext.Current.Session["requestToken"] = requestToken;
                //System.Web.HttpContext.Current.Response.Redirect(BaseUri + "/oauth/Authorize?oauth_token=" + requestToken.TokenKey.ToString());


                //string url = BaseUri + "/oauth/Authorize?oauth_token=" + requestToken.TokenKey.ToString();
                //string param = "";// "oauth_token=" + requestToken.TokenKey.ToString();

                //using (System.Net.WebClient client = new System.Net.WebClient())
                //{
                //    client.Headers[System.Net.HttpRequestHeader.ContentType] = "application/x-wwww-form-urlencoded";

                //    var result = client.UploadString(url, param);

                //}



            }
        }
        return requestToken;
    }



    public static Token Authorize(string urlAuthorize = "oauth/AccessToken", string urlCallback = "")
    {
        var consumer = new Consumer(ConsumerKey, ConsumeSecret);
        OAuthTokens Token = new OAuthTokens(BaseUri, urlAuthorize);
        Token AccessToken = new Token();
        var token = new Token
        {
            ConsumerKey = consumer.ConsumerKey,
            ConsumerSecret = consumer.ConsumerSecret
        };

        Uri uri = new Uri(BaseUri + "/" + urlAuthorize);

        if (System.Web.HttpContext.Current.Session["requestToken"] != null)
        {
            var requestToken = (Token)System.Web.HttpContext.Current.Session["requestToken"];
            var header = new HmacSha1Signer().CreateSignature(requestToken, uri, "POST", System.Web.HttpContext.Current.Request["oauth_verifier"].ToString(), urlCallback);

            var req = new HttpClient(BaseUri)
            {
                UserAgent = "Xero Api wrapper - " + consumer.ConsumerKey
            };

            req.AddHeader("Authorization", header);

            var response = req.Post("oauth/AccessToken", string.Empty);

            if (response.StatusCode != HttpStatusCode.OK)
            {
                throw new OAuthException(response.Body);
            }

            var qs = HttpUtility.ParseQueryString(response.Body);
            var expires = qs["oauth_expires_in"];
            var session = qs["oauth_session_handle"];

            AccessToken = new Token(consumer.ConsumerKey, consumer.ConsumerSecret)
            {
                TokenKey = qs["oauth_token"],
                TokenSecret = qs["oauth_token_secret"],
                OrganisationId = qs["xero_org_muid"]
            };
        }
        return AccessToken;
    }
}
