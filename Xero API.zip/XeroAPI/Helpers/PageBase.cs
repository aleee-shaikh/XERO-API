﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Xero.Api.Infrastructure.OAuth;

public class PageBase : System.Web.UI.Page
{
    Token _accessToken = new Token();

    public Token AccessToken
    {
        get
        {
            if (Session["AccessToken"] == null)
            {
                _accessToken = XeroApiHelper.Authorize("oauth/AccessToken", Request.Url.AbsoluteUri);
                Session["AccessToken"] = _accessToken;
            }

            return (Token)Session["AccessToken"];
        }
        set
        {
            _accessToken = value;
            Session["AccessToken"] = _accessToken;
        }
    }

    protected override void OnLoad(EventArgs e)
    {
        if (Session["requestToken"] == null)
        {
            Token requestToken = XeroApiHelper.GetRequestToken("oauth/RequestToken", Request.Url.AbsoluteUri);
            Response.Redirect(XeroApiHelper.BaseUri + "/oauth/Authorize?oauth_token=" + requestToken.TokenKey.ToString());
        }
        else
        {

            if (Session["AccessToken"] == null)
            {
                AccessToken = XeroApiHelper.Authorize("oauth/AccessToken", Request.Url.AbsoluteUri);

            }
        }
        base.OnLoad(e);
    }
}
