﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Xero.Api.Infrastructure.OAuth.Signing;
using Xero.Api.Infrastructure.OAuth;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

    public class BankTransactionsData
    {
        public string Id { get; set; }
        public string Status { get; set; }
        public string ProviderName { get; set; }
        public string DateTimeUTC { get; set; }
        public List<BankTransactionsRecords> BankTransactions { get; set; }

    }
    public class BankAccount
    {
        public string AccountID { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public class Contact
    {
        public string ContactID { get; set; }
        public string Name { get; set; }
        public string Addresses { get; set; }
        public string Phones { get; set; }
        public string ContactGroups { get; set; }
        public string ContactPersons { get; set; }
        public bool HasValidationErrors { get; set; }

    }
    public class BankTransactionsRecords
    {
        public string BankTransactionID { get; set; }
        public BankAccount bankAccount { get; set; }
        public string Type { get; set; }
        public string Reference { get; set; }
        public bool IsReconciled { get; set; }
        public bool HasAttachments { get; set; }
        public float SubTotal { get; set; }
        public float TotalTax { get; set; }
        public float Total { get; set; }
        public DateTime UpdatedDateUTC { get; set; }
        public string CurrencyCode { get; set; }
    }

    public static class BankTransactions
    {
        public static DataTable GetBankTransactions(Token AccessToken,string urlTransaction="api.xro/2.0/banktransactions")
        {
            Uri uriBankTransactions = new Uri(XeroApiHelper.BaseUri + "/" + urlTransaction);
            var header = new HmacSha1Signer().CreateSignature(AccessToken, uriBankTransactions, "GET", "", "");
            var req = new HttpClient(XeroApiHelper.BaseUri)
            {
                UserAgent = "Xero Api wrapper - " + XeroApiHelper.ConsumerKey
            };

            req.AddHeader("Authorization", header);
            var response = req.Get(urlTransaction, "");
            BankTransactionsData obj = JsonConvert.DeserializeObject<BankTransactionsData>(response.Body);
            var jsonLinq = JObject.Parse(response.Body);
            var srcArray = jsonLinq.Descendants().Where(d => d is JArray).First();
            var trgArray = new JArray();
            foreach (JObject row in srcArray.Children<JObject>())
            {
                var cleanRow = new JObject();
                foreach (JProperty column in row.Properties())
                {
                    if (column.Value is JValue)
                    {
                        cleanRow.Add(column.Name, column.Value);
                    }
                }

                trgArray.Add(cleanRow);
            }

            DataTable dt = JsonConvert.DeserializeObject<DataTable>(trgArray.ToString());

            return dt;
        }
    }
